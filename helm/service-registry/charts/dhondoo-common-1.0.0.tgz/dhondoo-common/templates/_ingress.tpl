{{- define "dhondoo.ingress" -}}

{{- if .Values.ingress.enabled }}

apiVersion: networking.k8s.io/v1
kind: Ingress

metadata:
  name: {{ include "dhondoo.fullname" . }}
  labels:
    {{- include "dhondoo.labels" . | nindent 4 }}

  {{- with .Values.ingress.annotations }}
  annotations:
{{ toYaml . | nindent 4 }}
  {{- end }}

spec:

  ingressClassName: {{ .Values.ingress.className }}

  {{- if .Values.ingress.tls }}
  tls:
{{ toYaml .Values.ingress.tls | nindent 4 }}
  {{- end }}

  rules:
{{- range .Values.ingress.hosts }}
    - host: {{ .host }}

      http:
        paths:
{{- range .paths }}
          - path: {{ .path }}
            pathType: {{ .pathType }}

            backend:
              service:
                name: {{ include "dhondoo.fullname" $ }}

                port:
                  number: {{ $.Values.service.port }}
{{- end }}
{{- end }}

{{- end }}

{{- end -}}
{{- define "dhondoo.pdb" -}}
{{- if .Values.pdb.enabled }}

apiVersion: policy/v1
kind: PodDisruptionBudget

metadata:
  name: {{ include "dhondoo.fullname" . }}
  labels:
    {{- include "dhondoo.labels" . | nindent 4 }}

spec:
  minAvailable: {{ .Values.pdb.minAvailable }}

  selector:
    matchLabels:
      {{- include "dhondoo.selectorLabels" . | nindent 6 }}

{{- end }}
{{- end -}}
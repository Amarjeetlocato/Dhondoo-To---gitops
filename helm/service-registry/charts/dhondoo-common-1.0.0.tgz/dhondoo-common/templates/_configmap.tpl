{{- define "dhondoo.configmap" -}}

{{- if .Values.configMap.enabled }}

apiVersion: v1
kind: ConfigMap

metadata:
  name: {{ include "dhondoo.fullname" . }}
  labels:
    {{- include "dhondoo.labels" . | nindent 4 }}

data:
{{- range $key, $value := .Values.configMap.data }}
  {{ $key }}: {{ $value | quote }}
{{- end }}

{{- end }}

{{- end -}}